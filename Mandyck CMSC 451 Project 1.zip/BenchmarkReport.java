// Melissa Mandyck
// CMSC 451
// Project 1
// Reads Benchmark file with Display of Results in Table Model
// Calculates Avg and Coefficients of Variations

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.*;

public class BenchmarkReport {

    public static void main(String[] args) throws Exception {

        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);

        File file = chooser.getSelectedFile();
        Scanner sc = new Scanner(file);

	// Table Column
        String[] columns = {"Size", "Avg Count", "Coef Count", "Avg Time", "Coef Time"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

	// Processes Each Line
        while (sc.hasNextLine()) {
            String[] tokens = sc.nextLine().trim().split("\\s+");

            int size = Integer.parseInt(tokens[0]);

            List<Long> counts = new ArrayList<>();
            List<Long> times = new ArrayList<>();

		// Extract Count and Time Pairs
            for (int i = 1; i < tokens.length; i += 2) {
                counts.add(Long.parseLong(tokens[i]));
                times.add(Long.parseLong(tokens[i + 1]));
            }
		// Compute Averages
            double avgCount = avg(counts);
            double avgTime = avg(times);

		// Computes Coefficient Variations
            double coefCount = coefVar(counts, avgCount);
            double coefTime = coefVar(times, avgTime);

	   // Add Rows to Table
            model.addRow(new Object[]{
                    size,
                    String.format("%.2f", avgCount),
                    String.format("%.2f%%", coefCount),
                    String.format("%.2f", avgTime),
                    String.format("%.2f%%", coefTime)
            });
        }

	// Display Table Model

        JTable table = new JTable(model);
        JOptionPane.showMessageDialog(null, new JScrollPane(table), "Benchmark Report", JOptionPane.PLAIN_MESSAGE);
    }
	// Calculates Average
    static double avg(List<Long> list) {
        return list.stream().mapToDouble(Long::doubleValue).average().orElse(0);
    }
	// Calculates Coefficient Variation
    static double coefVar(List<Long> list, double mean) {
        double variance = 0;
        for (long v : list) {
            variance += Math.pow(v - mean, 2);
        }
        variance /= list.size();
        double stdDev = Math.sqrt(variance);
        return (stdDev / mean) * 100;
    }
}