// Melissa Mandyck
// CMSC 451
// Project 1
// UnsortedException Thrown when Array Sorted Incorrectly 

public class UnsortedException extends Exception {
    public UnsortedException(String message) {
        super(message);
    }
}