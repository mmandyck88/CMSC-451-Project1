// Melissa Mandyck
// CMSC 451
// Project 1
// MergeSort Implementation to compare during merge

public class MergeSort extends AbstractSort {

    @Override
    public void sort(int[] array) {
        startSort(); 				// Starts timer and Resets counter
        mergeSort(array, 0, array.length - 1);
        endSort();				// Stops timer
    }

	// Recursive MergeSort
    private void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }
	// Merges the Two Sorted Halves Together

    private void merge(int[] arr, int left, int mid, int right) {
        int[] temp = new int[right - left + 1];
        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right) {
            incrementCount(); 			// for comparison
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
            }
        }
	// Copy Remaining Elements
        while (i <= mid) temp[k++] = arr[i++];
        while (j <= right) temp[k++] = arr[j++];

	// Copy back to Original Array

        for (i = 0; i < temp.length; i++) {
            arr[left + i] = temp[i];
        }
    }
}