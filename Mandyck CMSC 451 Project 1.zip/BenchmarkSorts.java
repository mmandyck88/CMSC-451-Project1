// Melissa Mandyck
// CMSC 451
// Project 1
// Main Program BenchmarkSort for MergeSort and QuickSort
// Generates Random Data, runs 40 Trials for 12 Sizes
// Records Operation Count and Execution Time 

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class BenchmarkSorts {

    static final int NUM_SIZES = 12;
    static final int NUM_TRIALS = 40;

    public static void main(String[] args) throws Exception {

        AbstractSort sort1 = new MergeSort();
        AbstractSort sort2 = new QuickSort();

	// Generates 12 Even Spaced Sizes
        int[] sizes = new int[NUM_SIZES];
        for (int i = 0; i < NUM_SIZES; i++) {
            sizes[i] = (i + 1) * 100; 
        }

        FileWriter out1 = new FileWriter("merge.txt");
        FileWriter out2 = new FileWriter("quick.txt");

        Random rand = new Random();

        // JVM Warm-up (Unrecorded)
        for (int i = 0; i < 5; i++) {
            int[] warm = randArray(1000, rand);
            sort1.sort(warm.clone());
            sort2.sort(warm.clone());
        }
	// BenchMark Loops
        for (int size : sizes) {

            out1.write(size + " ");
            out2.write(size + " ");

            for (int t = 0; t < NUM_TRIALS; t++) {

                int[] original = randArray(size, rand); // Generates Data for Both Sorts

                int[] a1 = original.clone();
                int[] a2 = original.clone();

		// Runs MergeSort
                sort1.sort(a1);
                verifySorted(a1);
	
		// Runs QuickSort
                sort2.sort(a2);
                verifySorted(a2);

                out1.write(sort1.getCount() + " " + sort1.getTime() + " ");
                out2.write(sort2.getCount() + " " + sort2.getTime() + " ");
            }

            out1.write("\n");
            out2.write("\n");
        }

        out1.close();
        out2.close();
    }
	// Generates Random Integer Array
    static int[] randArray(int size, Random rand) {
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rand.nextInt(10000);
        }
        return arr;
    }
	// Checks Array Sorted (if not Throws Exception) 
    static void verifySorted(int[] arr) throws UnsortedException {
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < arr[i - 1]) {
                throw new UnsortedException("Array is not sorted!");
            }
        }
    }
}