// Melissa Mandyck
// CMSC 451
// Project 1
// Abstract base class handles time and counting 

public abstract class AbstractSort {
    protected long count;
    protected long startTime;
    protected long elapsedTime;

    public abstract void sort(int[] array);

    // Initializes counter and records start time
    public void startSort() {
        count = 0;
        startTime = System.nanoTime();
    }
	// Calculates Elapsed Time After Sorting
    public void endSort() {
        elapsedTime = System.nanoTime() - startTime;
    }

    public void incrementCount() {
        count++;
    }

    public long getCount() {
        return count;
    }

    public long getTime() {
        return elapsedTime; // Total Elapsed time in nanoseconds
    }
}