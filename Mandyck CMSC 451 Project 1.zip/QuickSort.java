// Melissa Mandyck
// CMSC 451
// Project 1
// Quicksort Comparison with Pivots

public class QuickSort extends AbstractSort {

    @Override
    public void sort(int[] array) {
        startSort();
        quickSort(array, 0, array.length - 1);
        endSort();
    }
	// Recursive QuickSort
    private void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }
	// Partition Method with Last Element as Pivot
    private int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            incrementCount(); // comparison
            if (arr[j] < pivot) {
                i++;
                swap(arr, i, j);
            }
        }
	
        swap(arr, i + 1, high);		// Places Pivot to Correct Spot
        return i + 1;
    }
	// Swaps Two Elements in Array
    private void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}